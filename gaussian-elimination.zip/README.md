Gaussian Elimination
---
para probar el codigo en cada version paralelizado o en serie ingrese a la carpeta respectiva y ejecute :


```bash
  make
  # n numero de incognitas del sistema lineal
  ./run <n>
  # para generar  archivo salida con los datos montrados en el pdf
  :/salida-lineal.sh
```

los dos codigos se ciplaron y ejecutaron en el guene y local las salidas se movieron a data_gune
